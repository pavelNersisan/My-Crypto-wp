<?php
/**
 * The plugin bootstrap file.
 *
 * This file is responsible for setting up the plugin environment and loading
 * any necessary files.
 *
 * @link              https://www.pawelnersisian.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 */

// Define the plugin version.
define( 'MY_CRYPTO_PLUGIN_VERSION', '1.0.0' );

// Define the plugin directory path and URL.
define( 'MY_CRYPTO_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'MY_CRYPTO_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );

// Include the necessary files.
require_once MY_CRYPTO_PLUGIN_DIR_PATH . 'includes/class-my-crypto-plugin.php';
require_once MY_CRYPTO_PLUGIN_DIR_PATH . 'includes/class-my-crypto-plugin-widget.php';
require_once MY_CRYPTO_PLUGIN_DIR_PATH . 'utils/class-my-crypto-plugin-utils.php';
require_once MY_CRYPTO_PLUGIN_DIR_PATH . 'api/class-my-crypto-plugin-api.php';
require_once MY_CRYPTO_PLUGIN_DIR_PATH . 'shortcodes/class-my-crypto-plugin-shortcode.php';

// Register the activation and deactivation hooks.
register_activation_hook( __FILE__, array( 'My_Crypto_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'My_Crypto_Plugin', 'deactivate' ) );

// Instantiate the plugin.
My_Crypto_Plugin::get_instance();