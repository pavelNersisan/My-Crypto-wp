<?php
/**
 * The test class.
 *
 * This file defines the test class used by the plugin.
 *
 * @link              https://www.pawelnersisian.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 * @subpackage        My_Crypto_Plugin/tests
 */

/**
 * The test class.
 *
 * This class contains unit tests for the plugin.
 *
 * @since      1.0.0
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/tests
 */
class My_Crypto_Plugin_Test extends WP_UnitTestCase {

	/**
	 * Tests the get_cryptocurrency_data() function.
	 */
	function test_get_cryptocurrency_data() {
		// ...
	}

	/**
	 * Tests the get_api_url() function.
	 */
	function test_get_api_url() {
		// ...
	}

}