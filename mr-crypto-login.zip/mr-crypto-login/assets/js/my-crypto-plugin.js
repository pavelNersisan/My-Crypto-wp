// Code for fetching cryptocurrency data from the API and displaying it in a table
function display_cryptocurrency_table(cryptocurrency, limit) {
  var url = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=' + cryptocurrency + '&order=market_cap_desc&per_page=' + limit + '&page=1&sparkline=false';

  // Fetch cryptocurrency data from the API
  fetch(url)
    .then(response => response.json())
    .then(data => {
      // Build the table HTML
      var tableHTML = '<table class="cryptocurrency-table"><thead><tr><th>Name</th><th>Price</th><th>24h % Change</th><th>Market Cap</th></tr></thead><tbody>';
      data.forEach(crypto => {
        tableHTML += '<tr><td>' + crypto.name + '</td><td>$' + crypto.current_price + '</td><td>' + crypto.price_change_percentage_24h + '%</td><td>$' + crypto.market_cap + '</td></tr>';
      });
      tableHTML += '</tbody></table>';

      // Insert the table HTML into the DOM
      document.getElementById('my-crypto-plugin-table').innerHTML = tableHTML;
    })
    .catch(error => console.error(error));
}

// Code for fetching cryptocurrency data from the API and displaying it in a chart
function display_cryptocurrency_chart(cryptocurrency, days) {
  var url = 'https://api.coingecko.com/api/v3/coins/' + cryptocurrency + '/market_chart?vs_currency=usd&days=' + days;

  // Fetch cryptocurrency data from the API
  fetch(url)
    .then(response => response.json())
    .then(data => {
      // Extract the data for the chart
      var labels = data.prices.map(price => new Date(price[0]).toLocaleDateString());
      var prices = data.prices.map(price => price[1]);

      // Build the chart using Chart.js
      var ctx = document.getElementById('my-crypto-plugin-chart').getContext('2d');
      var chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: cryptocurrency,
            data: prices,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
    })
    .catch(error => console.error(error));
}