<?php
/**
 * The utility class.
 *
 * This file defines the utility class used by the plugin.
 *
 * @link              https://www.example.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 * @subpackage        My_Crypto_Plugin/utils
 */

/**
 * The utility class.
 *
 * This class contains utility functions used by the plugin.
 *
 * @since      1.0.0
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/utils
 */
class My_Crypto_Plugin_Utils {

	/**
	 * Returns an array of cryptocurrency data.
	 *
	 * This function queries the CoinMarketCap API to retrieve the latest data
	 * for the specified cryptocurrency and returns it as an array.
	 *
	 * @since  1.0.0
	 * @param  string $cryptocurrency The cryptocurrency symbol (e.g. BTC).
	 * @param  int    $limit          The maximum number of results to return.
	 * @param  int    $days           The number of days of historical data to retrieve.
	 * @return array                  An array of cryptocurrency data.
	 */
	public static function get_cryptocurrency_data( $cryptocurrency, $limit = 10, $days = 30 ) {
		// ...
	}

	/**
	 * Returns the URL for the CoinMarketCap API.
	 *
	 * This function constructs the URL for the CoinMarketCap API based on the
	 * specified cryptocurrency, limit, and days parameters.
	 *
	 * @since  1.0.0
	 * @param  string $cryptocurrency The cryptocurrency symbol (e.g. BTC).
	 * @param  int    $limit          The maximum number of results to return.
	 * @param  int    $days           The number of days of historical data to retrieve.
	 * @return string                 The URL for the CoinMarketCap API.
	 */
	private static function get_api_url( $cryptocurrency, $limit, $days ) {
		// ...
	}

}