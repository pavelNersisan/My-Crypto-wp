<?php
/**
 * The API endpoints.
 *
 * This file defines the API endpoints used by the plugin.
 *
 * @link              https://www.pawelnersisian.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 * @subpackage        My_Crypto_Plugin/api
 */

/**
 * Registers the API endpoints.
 *
 * This function registers the API endpoints used by the plugin using the
 * register_rest_route() function provided by the WordPress REST API.
 *
 * @since  1.0.0
 */
function my_crypto_plugin_register_api_endpoints() {
	// ...
}
add_action( 'rest_api_init', 'my_crypto_plugin_register_api_endpoints' );

/**
 * Retrieves the cryptocurrency data.
 *
 * This function retrieves the latest data for the specified cryptocurrency
 * from the CoinMarketCap API and returns it as an array.
 *
 * @since  1.0.0
 * @param  WP_REST_Request $request The REST API request object.
 * @return array                    An array of cryptocurrency data.
 */
function my_crypto_plugin_get_cryptocurrency_data( $request ) {
	// ...
}