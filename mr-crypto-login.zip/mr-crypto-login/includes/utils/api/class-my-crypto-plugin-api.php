<?php
/**
 * The API class.
 *
 * This file defines the API class used by the plugin.
 *
 * @link              https://www.pawelnersisian.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 * @subpackage        My_Crypto_Plugin/api
 */

/**
 * The API class.
 *
 * This class contains functions used to interact with external APIs.
 *
 * @since      1.0.0
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/api
 */
class My_Crypto_Plugin_API {

	/**
	 * Makes a GET request to the specified URL and returns the response.
	 *
	 * This function makes a GET request to the specified URL using the
	 * wp_remote_get() function and returns the response as a string.
	 *
	 * @since  1.0.0
	 * @param  string $url The URL to request.
	 * @return string      The response from the API.
	 */
	public static function get( $url ) {
		// ...
	}

}