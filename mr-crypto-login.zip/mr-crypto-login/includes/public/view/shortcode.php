<div class="my-crypto">
	<table>
		<thead>
			<tr>
				<th><?php esc_html_e( 'Cryptocurrency', 'my-crypto-plugin' ); ?></th>
				<th><?php esc_html_e( 'Price', 'my-crypto-plugin' ); ?></th>
				<th><?php esc_html_e( 'Market Cap', 'my-crypto-plugin' ); ?></th>
				<th><?php esc_html_e( 'Change (24h)', 'my-crypto-plugin' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $cryptocurrencies as $cryptocurrency ) : ?>
				<tr>
					<td><?php echo esc_html( $cryptocurrency['name'] ); ?></td>
					<td><?php echo esc_html( $cryptocurrency['price'] ); ?></td>
					<td><?php echo esc_html( $cryptocurrency['market_cap'] ); ?></td>
					<td><?php echo esc_html( $cryptocurrency['change_24h'] ); ?>%</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>