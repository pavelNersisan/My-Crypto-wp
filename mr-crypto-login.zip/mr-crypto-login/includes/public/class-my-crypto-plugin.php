<?php
/**
 * The main plugin file.
 *
 * This file is responsible for loading the plugin.
 *
 * @link              https://www.example.com
 * @since             1.0.0
 * @package           My_Crypto_Plugin
 *
 * @wordpress-plugin
 * Plugin Name:       My Crypto Plugin
 * Plugin URI:        https://www.example.com/my-crypto-plugin/
 * Description:       A plugin for displaying cryptocurrency data.
 * Version:           1.0.0
 * Author:            John Doe
 * Author URI:        https://www.example.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       my-crypto-plugin
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * @since      1.0.0
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/includes
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-my-crypto-plugin.php';

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_my_crypto_plugin() {

	$plugin = new My_Crypto_Plugin();
	$plugin->run();

}
run_my_crypto_plugin();