<?php
/**
 * The widget-specific functionality of the plugin.
 *
 * @link       https://example.com/
 * @since      1.0.0
 *
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/includes/views
 */

/**
 * The widget-specific functionality of the plugin.
 *
 * Defines the widget class and two hooks for registering
 * and rendering the widget.
 *
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/includes/views
 */
class My_Crypto_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'my_crypto_widget', // Base ID
			esc_html__( 'My Crypto Widget', 'my-crypto-plugin' ), // Name
			array( 'description' => esc_html__( 'Displays cryptocurrency data in a table or chart', 'my-crypto-plugin' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		// Display the table or chart based on the widget settings
		if ( $instance['display'] == 'table' ) {
			display_cryptocurrency_table( $instance['cryptocurrency'], $instance['limit'] );
		} else {
			display_cryptocurrency_chart( $instance['cryptocurrency'], $instance['days'] );
		}
		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'my-crypto-plugin' );
		$display = ! empty( $instance['display'] ) ? $instance['display'] : 'table';
		$cryptocurrency = ! empty( $instance['cryptocurrency'] ) ? $instance['cryptocurrency'] : 'bitcoin';
		$limit = ! empty( $instance['limit'] ) ? $instance['limit'] : 10;
		$days = ! empty( $instance['days'] ) ? $instance['days'] : 7;
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'my-crypto-plugin' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<input type="radio" id="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-table" name="<?php echo esc_attr( $this->get_field_name( 'display' ) ); ?>" value="table" <?php checked( $display, 'table' ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-table">Table</label>
			<input type="radio" id="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-chart" name="<?php echo esc_attr( $this->get_field_name( 'display' ) ); ?>" value="chart" <?php checked( $display, 'chart' ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-chart">Chart</label>
		</p>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'cryptocurrency' ) ); ?>"><?php esc_attr_e( 'Cryptocurrency:', 'my-crypto-plugin' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'cryptocurrency' ) ); ?>" name="<?php echo escGreat! Here's an example of what the `widgets.php` file might contain:

```php
<?php
/**
 * The widget-specific functionality of the plugin.
 *
 * @link       https://example.com/
 * @since      1.0.0
 *
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/includes/views
 */

/**
 * The widget-specific functionality of the plugin.
 *
 * Defines the widget class and two hooks for registering
 * and rendering the widget.
 *
 * @package    My_Crypto_Plugin
 * @subpackage My_Crypto_Plugin/includes/views
 */
class My_Crypto_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'my_crypto_widget', // Base ID
			esc_html__( 'My Crypto Widget', 'my-crypto-plugin' ), // Name
			array( 'description' => esc_html__( 'Displays cryptocurrency data in a table or chart', 'my-crypto-plugin' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		// Display the table or chart based on the widget settings
		if ( $instance['display'] == 'table' ) {
			display_cryptocurrency_table( $instance['cryptocurrency'], $instance['limit'] );
		} else {
			display_cryptocurrency_chart( $instance['cryptocurrency'], $instance['days'] );
		}
		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'my-crypto-plugin' );
		$display = ! empty( $instance['display'] ) ? $instance['display'] : 'table';
		$cryptocurrency = ! empty( $instance['cryptocurrency'] ) ? $instance['cryptocurrency'] : 'bitcoin';
		$limit = ! empty( $instance['limit'] ) ? $instance['limit'] : 10;
		$days = ! empty( $instance['days'] ) ? $instance['days'] : 7;
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'my-crypto-plugin' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<input type="radio" id="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-table" name="<?php echo esc_attr( $this->get_field_name( 'display' ) ); ?>" value="table" <?php checked( $display, 'table' ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-table">Table</label>
			<input type="radio" id="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-chart" name="<?php echo esc_attr( $this->get_field_name( 'display' ) ); ?>" value="chart" <?php checked( $display, 'chart' ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>-chart">Chart</label>
		</p>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'cryptocurrency' ) ); ?>"><?php esc_attr_e( 'Cryptocurrency:', 'my-crypto-plugin' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'cryptocurrency' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'cryptocurrency' ) ); ?>" type="text" value="<?php echo esc