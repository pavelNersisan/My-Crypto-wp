<div class="wrap">
  <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
  <form method="post" action="options.php">
    <?php settings_fields( 'my-crypto-plugin-settings' ); ?>
    <?php do_settings_sections( 'my-crypto-plugin-settings' ); ?>
    <table class="form-table">
      <tr valign="top">
        <th scope="row"><?php esc_html_e( 'Cryptocurrency', 'my-crypto-plugin' ); ?></th>
        <td>
          <input type="text" name="my-crypto-plugin-cryptocurrency" value="<?php echo esc_attr( get_option( 'my-crypto-plugin-cryptocurrency' ) ); ?>" />
        </td>
      </tr>
      <tr valign="top">
        <th scope="row"><?php esc_html_e( 'Maximum items', 'my-crypto-plugin' ); ?></th>
        <td>
          <input type="number" name="my-crypto-plugin-limit" min="1" max="100" value="<?php echo esc_attr( get_option( 'my-crypto-plugin-limit', 10 ) ); ?>" />
        </td>
      </tr>
      <tr valign="top">
        <th scope="row"><?php esc_html_e( 'Days of data', 'my-crypto-plugin' ); ?></th>
        <td>
          <input type="number" name="my-crypto-plugin-days" min="1" max="365" value="<?php echo esc_attr( get_option( 'my-crypto-plugin-days', 7 ) ); ?>" />
        </td>
      </tr>
    </table>
    <?php submit_button(); ?>
  </form>
</div>